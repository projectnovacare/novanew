const o={};throw new Error('Could not resolve "@coinbase/wallet-sdk" imported by "@wagmi/connectors".');export{o as default};
